package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import units.Infantry;
import units.Unit;

public class Barracks extends MilitaryBuilding {

	public Barracks() {
		super(2000, 1000, 500);
	}
	
	public void upgrade() throws BuildingInCoolDownException, MaxLevelException{
		super.upgrade();
		setUpgradeCost(1500);
		if(getLevel()==2)
			setRecruitmentCost(550);
		else
			setRecruitmentCost(600);
		
	}
	
	public Unit recruit() throws BuildingInCoolDownException,
	MaxRecruitedException{
		
		if(isCoolDown())
			throw new BuildingInCoolDownException();
		if (getCurrentRecruit()== getMaxRecruit())
			throw new MaxRecruitedException();
		Unit u = null;
		
		int unitLevel=getLevel();
		
       if (unitLevel == 1)
		  u = (new Infantry(1, 50, 0.5, 0.6, 0.7));
		
		else if (unitLevel == 2)
		  u = (new Infantry(2, 50, 0.5, 0.6, 0.7));
		
		else
		   u = (new Infantry(3, 60, 0.6, 0.7, 0.8));
       setCurrentRecruit(getCurrentRecruit()+1);
       
       return u;
	}

}
