package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import units.Cavalry;
import units.Unit;

public class Stable extends MilitaryBuilding {

	public Stable() {
		super(2500, 1500, 600);
	}
	
	public void upgrade() throws BuildingInCoolDownException, MaxLevelException{
		super.upgrade();
		setUpgradeCost(2000);
		if(getLevel()==2)
			setRecruitmentCost(650);
		else
			setRecruitmentCost(700);
	}
	
	public Unit recruit() throws BuildingInCoolDownException,
	MaxRecruitedException{
		
		if(isCoolDown())
			throw new BuildingInCoolDownException();
		if (getCurrentRecruit()== getMaxRecruit())
			throw new MaxRecruitedException();
		Unit u = null;
		
		int unitLevel=getLevel();
    	   
    	   if (unitLevel == 1)
				u = (new Cavalry(1, 40, 0.6, 0.7, 0.75));

			else if (unitLevel == 2)
				u = (new Cavalry(2, 40, 0.6, 0.7, 0.75));
			else
				u = (new Cavalry(3, 60, 0.7, 0.8, 0.9));
    	   
    	   setCurrentRecruit(getCurrentRecruit()+1);
    	   return u;
    	   
	}
	

}
