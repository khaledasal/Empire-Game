package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import units.Archer;
import units.Unit;

public class ArcheryRange extends MilitaryBuilding {

	public ArcheryRange() {
		super(1500, 800, 400);

	}
	
	public void upgrade() throws BuildingInCoolDownException, MaxLevelException{
		super.upgrade();
		setUpgradeCost(700);
		if(getLevel()==2)
			setRecruitmentCost(450);
		else
			setRecruitmentCost(500);
	}
	public Unit recruit() throws BuildingInCoolDownException,
	MaxRecruitedException{
		if(isCoolDown())
			throw new BuildingInCoolDownException();
		if (getCurrentRecruit()== getMaxRecruit())
			throw new MaxRecruitedException();
		Unit u = null;
		int l = getLevel();
		if (l == 1)
			u = (new Archer(1, 60, 0.4, 0.5, 0.6));

		else if (l == 2)
			u = (new Archer(2, 60, 0.4, 0.5, 0.6));
		else
			u = (new Archer(3, 70, 0.5, 0.6, 0.7));
		setCurrentRecruit(getCurrentRecruit()+1);
		return u;
	}

}
