package Controller;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ResourceBundle.Control;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import View.*;
import buildings.*;
import engine.*;
import exceptions.BuildingInCoolDownException;
import exceptions.FriendlyCityException;
import exceptions.FriendlyFireException;
import exceptions.MaxCapacityException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import exceptions.NotEnoughGoldException;
import exceptions.TargetNotReachedException;
import units.Archer;
import units.Army;
import units.Unit;

public class Controller implements GameListener, ActionListener, ListSelectionListener {
	private Game game;
	private View view;
	private City chosedCity;
	private Unit relocatedUnit;
	private String handledUnit;
	private Army armyTargeted;
	// private ArrayList<CityPanelEnemy>;

	public Controller() throws IOException, InterruptedException {
		GameIntro intro = new GameIntro();
		intro.setVisible(true);
		waitForEnter(intro.getButton());
		intro.dispose();
		Game game = new Game(intro.getPlayerName(), intro.getCityName());
		// game.getPlayer().initiateArmy(game.getAvailableCities().get(0), new Archer(1,
		// 100, 10, 10, 10));
		this.game = game;
		game.setListener(this);
		View view = new View(game.getPlayer().getName(), game.getAvailableCities(), game.getPlayer().getFood(),
				game.getPlayer().getTreasury());
		this.view = view;
		view.setVisible(true);
		for (CityView button : view.getMyCities()) {
			button.addActionListener(this);
		}
		view.getPp().getEndTurn().addActionListener(this);
		// JOptionPane.showMessageDialog(null,
		// game.getAvailableCities().get(0).getName());
		// EconomicBuildingPanel p = (EconomicBuildingPanel) view.getInfo();
		// p.getUpgrade().addActionListener(this);
		view.revalidate();
	}

	public static void waitForEnter(JButton b) throws InterruptedException {
		synchronized (b) {
			try {
				b.wait();
			} catch (InterruptedException ex) {
			}
		}
		JOptionPane.showMessageDialog(null, "Let's Begin...");
		// System.exit(0);
	}

	@Override
	public void Onattack(Unit unit, Army attacker, Unit u, Army defender, int past, boolean b) {
		String txt = "";
		String txt2 = "";
		AttackPanel ap = (AttackPanel) view.getInfo();
		// JOptionPane.showMessageDialog(null,attacker.getUnits().size() + " " +
		// defender.getUnits().size());
		if (b) {
			if (defender.getUnits().contains(u)) {
				txt = "Unit " + ap.getMylistString()[attacker.getUnits().indexOf(unit)]
						+ " in your Army, attacked Unit";
				txt2 = ap.getEnemylistString()[defender.getUnits().indexOf(u)] + " in Enemy Army." + "His unit lost"
						+ (past - u.getCurrentSoldierCount()) + "Soldiers";
			} else {
				txt = "Unit " + ap.getMylistString()[attacker.getUnits().indexOf(unit)]
						+ " in your Army, attacked Unit";
				txt2 = this.handledUnit + "in Enemy Army." + "\n" + "His unit lost all (" + past + ") Soldiers";
			}
		} else {
			if (defender.getUnits().contains(u)) {
				txt = "Unit " + ap.getEnemylistString()[attacker.getUnits().indexOf(unit)]
						+ " in Enemy Army, attacked Unit";
				txt2 = ap.getMylistString()[defender.getUnits().indexOf(u)] + " in Your Army." + "\n" + "Your unit lost"
						+ (past - u.getCurrentSoldierCount()) + "Soldiers";
			} else {
				txt = "Unit " + ap.getEnemylistString()[attacker.getUnits().indexOf(unit)]
						+ " in Enemy Army, attacked Unit";
				txt2 = this.handledUnit + "in Your Army." + "\n" + "Your unit lost all (" + past + ") Soldiers";
			}
		}
		LogPanel pan = null;
		for (LogPanel panel : view.getLogs()) {
			if (attacker == panel.getAttacker() || attacker == panel.getDefender()) {
				pan = panel;
			}
		}
		pan.addLogText(txt);
		pan.addLogText(txt2);
		pan.revalidate();
		pan.repaint();
		view.revalidate();
		view.repaint();
	}

	@Override
	public void onRelocateUnit(Army army) {
		ArmyPanel ap = new ArmyPanel(army);
		for (JButton button : ap.getButtons()) {
			button.addActionListener(this);
		}
		ap.getList().addListSelectionListener(this);
		view.addInfoPanel(ap);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnRemoveArmy(Army attacker) {
		//JOptionPane.showMessageDialog(null, "You clicked on Remove Army");
		AttackPanelButton button = null;
		for (AttackPanelButton b : view.getPp().getButtons()) {
			if (b.getAttacker() == attacker)
				button = b;
		}
		if (button != null)
			view.getPp().removeAttackPanel(button);
		LogPanel panel = null;
		for (LogPanel p : view.getLogs()) {
			if (p.getAttacker() == attacker)
				panel = p;
		}
		panel.addLogText("You lost the Battle and Your Army");
		view.getCap().removeControlledArmyButton(attacker);
		view.getCap().revalidate();
		view.getCap().repaint();
		view.getPp().getEndTurn().setEnabled(true);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnInitiateArmy(Army army, Unit unit) {
		view.getCap().addControlledArmyButton(army);
		view.getCap().getButtons().get(view.getCap().getButtons().size() - 1).addActionListener(this);
		view.getCap().revalidate();
		view.getCap().repaint();
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnHandleAttackedUnit(Unit u, Army a, int index) {
		AttackPanel ap = (AttackPanel) view.getInfo();
		Army myArmy = ap.getMyarmy();
		String unitName = "";
		if (a == myArmy) {
			unitName = ap.getMylistString()[index];
		} else {
			unitName = ap.getEnemylistString()[index];
		}
		this.handledUnit = unitName;
		AttackPanel re = new AttackPanel(ap.getMyarmy(), ap.getEnemyarmy());
		view.addInfoPanel(re);
		re.getAttack().addActionListener(this);
		re.getMylist().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				int index = re.getMylist().getSelectedIndex();
				Unit u = re.getMyarmy().getUnits().get(index);
				UnitPanelEnemy frame = new UnitPanelEnemy(u);
				view.addBattleUnitFrame(frame);
			}
		});
		re.getEnemylist().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				int index = re.getEnemylist().getSelectedIndex();
				Unit u = re.getEnemyarmy().getUnits().get(index);
				UnitPanelEnemy frame = new UnitPanelEnemy(u);
				view.addBattleUnitFrame(frame);
			}
		});
		view.addInfoPanel(re);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnTargetCity(Army army, String targetName) {
		ArmyPanel ap = new ArmyPanel(army);
		for (JButton button : ap.getButtons()) {
			button.addActionListener(this);
		}
		ap.getList().addListSelectionListener(this);
		view.addInfoPanel(ap);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnEndTurn() {
		int s = view.getLogs().size();
		for (int i = 0; i < s; i++) {
			view.removeLog(view.getLogs().get(0));
		}
		PlayerPanel pl = view.getPp();
		for (AttackPanelButton button : pl.getButtons()) {
			pl.removeAttackPanel(button);
		}
		view.removeInfoPanel();
		pl.changeTreasury(game.getPlayer().getTreasury());
		pl.changeFood(game.getPlayer().getFood());
		pl.changeTurnsCount(game.getCurrentTurnCount());
		// JOptionPane.showMessageDialog(null, "You clicked on");
		if (game.isGameOver()) {
			if (game.getAvailableCities().size() == game.getPlayer().getControlledCities().size()) {
				JOptionPane.showMessageDialog(null, "You won the game!");
			} else {
				JOptionPane.showMessageDialog(null, "You lost the game!");
			}
			System.exit(0);
		}
		for(Army army: game.getPlayer().getControlledArmies()) {
			if(army.isShouldAttack()) {
			JOptionPane.showMessageDialog(null, "You should either attack the city manually or autoresolve it");
			ArmyPanel ap = new ArmyPanel(army);
			for (JButton button : ap.getButtons()) {
				button.addActionListener(this);
				if (button.getActionCommand().equals("Lay Seige") || button.getActionCommand().equals("Set Target"))
					button.setEnabled(false);
			}
			ap.getList().addListSelectionListener(this);
			view.addInfoPanel(ap);
			view.getPp().getEndTurn().setEnabled(false);
		}
		}
		pl.revalidate();
		pl.repaint();
		view.repaint();
		view.revalidate();
	}

	@Override
	public void OnOccupy(Army a, String cityName) {
		LogPanel panel = null;
		for (LogPanel p : view.getLogs()) {
			if (p.getAttacker() == a)
				panel = p;
		}
		AttackPanelButton button = null;
		for (AttackPanelButton b : view.getPp().getButtons()) {
			if (b.getAttacker() == a)
				button = b;
		}
		panel.addLogText("You Conquered the City");
		if (button != null)
		view.getPp().removeAttackPanel(button);
		view.getPp().getEndTurn().setEnabled(true);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnRecruitUnit(String type, String cityName) {
		view.getPp().changeTreasury(game.getPlayer().getTreasury());
		MilitaryBuildingPanel i = (MilitaryBuildingPanel) view.getInfo();
		i.setCurrentRecruit();
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnBuilt(Building b) {
		if (b instanceof EconomicBuilding) {
			EconomicBuildingPanel panel = new EconomicBuildingPanel((EconomicBuilding) b, true, (EconomicBuilding) b);
			if (panel.getUpgrade() != null)
				panel.getUpgrade().addActionListener(this);
			view.addInfoPanel(panel);
		} else {
			MilitaryBuildingPanel panel = new MilitaryBuildingPanel((MilitaryBuilding) b, true, (MilitaryBuilding) b);
			panel.getUpgrade().addActionListener(this);
			panel.getRecruit().addActionListener(this);
			view.addInfoPanel(panel);
		}
		view.getPp().changeTreasury(game.getPlayer().getTreasury());
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnUpgradeBuilding(Building b) {
		// JOptionPane.showMessageDialog(null, "gvv");
		if (b instanceof EconomicBuilding) {
			EconomicBuildingPanel panel = new EconomicBuildingPanel((EconomicBuilding) b, true, (EconomicBuilding) b);
			panel.getUpgrade().addActionListener(this);
			view.addInfoPanel(panel);
		} else {
			MilitaryBuildingPanel panel = new MilitaryBuildingPanel((MilitaryBuilding) b, true, (MilitaryBuilding) b);
			panel.getUpgrade().addActionListener(this);
			panel.getRecruit().addActionListener(this);
			view.addInfoPanel(panel);
		}
		view.getPp().changeTreasury(game.getPlayer().getTreasury());
		view.revalidate();
		view.repaint();
	}

	@Override
	public void OnLaySiege(Army army, City city) {
		ArmyPanel ap = new ArmyPanel(army);
		for (JButton button : ap.getButtons()) {
			button.addActionListener(this);
		}
		ap.getList().addListSelectionListener(this);
		view.addInfoPanel(ap);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for (CityView c : view.getMyCities()) {
			if (c == e.getSource()) {

				// this.view.removeInfoPanel();
				if (armyTargeted != null) {

					game.targetCity(armyTargeted, c.getThisCity().getName());
					armyTargeted = null;
					return;
				}
				if (!game.getPlayer().getControlledCities().contains(c.getThisCity())) {

					return;
				}
				// JOptionPane.showMessageDialog(null, "You clicked on ");
				if (relocatedUnit != null) {
					try {
						c.getThisCity().getDefendingArmy().relocateUnit(relocatedUnit);
						// JOptionPane.showMessageDialog(null, "Unit relocated");
					} catch (MaxCapacityException e1) {
						JOptionPane.showMessageDialog(null, "Max Capacity");
					}
					relocatedUnit = null;
					return;
				} else {
					// JOptionPane.showMessageDialog(null, "You clicked on this");
					chosedCity = c.getThisCity();
					CityPanel city = new CityPanel(c.getThisCity());
					for (JButton b : city.getButtons()) {
						b.addActionListener(this);
					}
					view.addInfoPanel(city);
					view.revalidate();
					view.repaint();
					return;
				}
			}
		}
		// info
		JPanel info = view.getInfo();
		// citypanel
		if (info instanceof CityPanel) {
			CityPanel i = (CityPanel) info;
			if (e.getActionCommand().equals("Farm")) {
				boolean built = false;
				EconomicBuilding E = null;
				for (EconomicBuilding EM : i.getCity().getEconomicalBuildings()) {
					if (EM instanceof Farm) {
						E = EM;
						built = true;
					}
				}
				Farm a = new Farm();
				EconomicBuildingPanel panel = new EconomicBuildingPanel(E, built, a);
				panel.setType1("Farm");
				if (panel.getUpgrade() != null)
					panel.getUpgrade().addActionListener(this);
				if (panel.getBuild() != null)
					panel.getBuild().addActionListener(this);
				view.addInfoPanel(panel);
				view.revalidate();
				view.repaint();
				return;
			}
			if (e.getActionCommand().equals("Market")) {
				boolean built = false;
				EconomicBuilding E = null;
				for (EconomicBuilding EM : i.getCity().getEconomicalBuildings()) {
					if (EM instanceof Market) {
						E = EM;
						built = true;
					}
				}
				Market a = new Market();
				EconomicBuildingPanel panel = new EconomicBuildingPanel(E, built, a);
				panel.setType1("Market");
				if (panel.getUpgrade() != null)
					panel.getUpgrade().addActionListener(this);
				if (panel.getBuild() != null)
					panel.getBuild().addActionListener(this);
				view.addInfoPanel(panel);
				view.revalidate();
				view.repaint();
				return;
			}
			if (e.getActionCommand().equals("Barraks")) {
				boolean built = false;
				MilitaryBuilding E = null;
				for (MilitaryBuilding EM : i.getCity().getMilitaryBuildings()) {
					if (EM instanceof Barracks) {
						E = EM;
						built = true;
					}
				}
				Barracks a = new Barracks();
				MilitaryBuildingPanel panel = new MilitaryBuildingPanel(E, built, a);
				panel.setType1("Barracks");
				if (panel.getUpgrade() != null)
					panel.getUpgrade().addActionListener(this);
				if (panel.getBuild() != null)
					panel.getBuild().addActionListener(this);
				if (panel.getRecruit() != null)
					panel.getRecruit().addActionListener(this);
				view.addInfoPanel(panel);
				view.revalidate();
				view.repaint();
				return;
			}
			if (e.getActionCommand().equals("Stable")) {
				boolean built = false;
				MilitaryBuilding E = null;
				for (MilitaryBuilding EM : i.getCity().getMilitaryBuildings()) {
					if (EM instanceof Stable) {
						E = EM;
						built = true;
					}
				}
				Stable a = new Stable();
				MilitaryBuildingPanel panel = new MilitaryBuildingPanel(E, built, a);
				panel.setType1("Stable");
				if (panel.getUpgrade() != null)
					panel.getUpgrade().addActionListener(this);
				if (panel.getBuild() != null)
					panel.getBuild().addActionListener(this);
				if (panel.getRecruit() != null)
					panel.getRecruit().addActionListener(this);
				view.addInfoPanel(panel);
				view.revalidate();
				view.repaint();
				return;
			}
			if (e.getActionCommand().equals("Archery Range")) {
				boolean built = false;
				MilitaryBuilding E = null;
				for (MilitaryBuilding EM : i.getCity().getMilitaryBuildings()) {
					if (EM instanceof ArcheryRange) {
						E = EM;
						built = true;
					}
				}
				ArcheryRange a = new ArcheryRange();
				MilitaryBuildingPanel panel = new MilitaryBuildingPanel(E, built, a);
				panel.setType1("ArcheryRange");
				if (panel.getUpgrade() != null)
					panel.getUpgrade().addActionListener(this);
				if (panel.getBuild() != null)
					panel.getBuild().addActionListener(this);
				if (panel.getRecruit() != null)
					panel.getRecruit().addActionListener(this);
				view.addInfoPanel(panel);
				view.revalidate();
				view.repaint();
				return;
			}
			// edit??
			if (e.getActionCommand().equals("Army")) {
				ArmyPanel ap = new ArmyPanel(i.getCity().getDefendingArmy());
				for (JButton button : ap.getButtons()) {
					button.setEnabled(false);
				}
				ap.getList().addListSelectionListener(this);
				view.addInfoPanel(ap);
				view.revalidate();
				view.repaint();
				return;
			}
		}
		// EconomicBuildingPanel
		if (info instanceof EconomicBuildingPanel) {
			EconomicBuildingPanel i = (EconomicBuildingPanel) info;
			if (e.getActionCommand().equals("Upgrade")) {
				try {
					// JOptionPane.showMessageDialog(null, "upgrade");
					game.getPlayer().upgradeBuilding(i.getEM());
					;
				} catch (BuildingInCoolDownException | MaxLevelException | NotEnoughGoldException e1) {
					JOptionPane.showMessageDialog(null, "Couldn't Upgrade");
				}
				return;
			}
			if (e.getActionCommand().equals("Build")) {
				try {
					game.getPlayer().build(i.getType1(), chosedCity.getName());
				} catch (NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				;
				return;
			}
		}
		// MilitaryBuildingPanel
		if (info instanceof MilitaryBuildingPanel) {
			MilitaryBuildingPanel i = (MilitaryBuildingPanel) info;
			if (e.getActionCommand().equals("Upgrade")) {
				try {
					game.getPlayer().upgradeBuilding(i.getMB());
				} catch (BuildingInCoolDownException | MaxLevelException | NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "Coudn't Upgrade");
				}
				return;
			}
			if (e.getActionCommand().equals("Build")) {
				try {
					game.getPlayer().build(i.getType1(), chosedCity.getName());
				} catch (NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
			if (e.getActionCommand().equals("Recruit")) {
				try {
					MilitaryBuilding type = i.getTypeB();
					String unit = "";
					if (type instanceof Barracks)
						unit = "Infantry";
					if (type instanceof Stable)
						unit = "cavalry";
					if (type instanceof ArcheryRange)
						unit = "archer";
					game.getPlayer().recruitUnit(unit, chosedCity.getName());
				} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
		}
		// ArmyPanel
		// continue
		if (info instanceof ArmyPanel) {
			ArmyPanel ap = (ArmyPanel) info;
			Army a = ap.getArmy();
			if (e.getActionCommand().equals("Set Target")) {
				if (armyTargeted == null) {
					this.armyTargeted = a;
					JOptionPane.showMessageDialog(null, "Choose a City to target ..Or Click again to Cancel");
				} else {
					armyTargeted = null;
					JOptionPane.showMessageDialog(null, "Army deselected");
				}
			}
			if (e.getActionCommand().equals("Auto Resolve") || e.getActionCommand().equals("Manual")
					|| e.getActionCommand().equals("Lay Seige")) {
				// fetch city
				String city = a.getCurrentLocation();
				City city1 = null;
				for (City c : game.getAvailableCities()) {
					if (c.getName().toLowerCase().equals(city.toLowerCase()))
						city1 = c;
				}
				//JOptionPane.showMessageDialog(null, "hiii");
				if (city1 == null)
					return;
				if (game.getPlayer().getControlledCities().contains(city1))
					return;
				// first command
				if (e.getActionCommand().equals("Auto Resolve")) {
					a.setShouldAttack(false);
					//JOptionPane.showMessageDialog(null, "auto");
					AttackPanel attack = new AttackPanel(a, city1.getDefendingArmy());
					view.addInfoPanel(attack);
					attack.getAttack().setEnabled(false);
					LogPanel lp = new LogPanel(a, city1.getDefendingArmy());
					view.addLog(lp);
					try {
						game.autoResolve(a, city1.getDefendingArmy());
					} catch (FriendlyFireException | MaxCapacityException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					// view.getPp().getEndTurn().setEnabled(false);
					view.revalidate();
					view.repaint();
				}
				if (e.getActionCommand().equals("Manual")) {
					a.setShouldAttack(false);
					//JOptionPane.showMessageDialog(null, "manual");
					AttackPanel attack = new AttackPanel(a, city1.getDefendingArmy());
					attack.getAttack().addActionListener(this);
					attack.getMylist().addListSelectionListener(new ListSelectionListener() {
						@Override
						public void valueChanged(ListSelectionEvent e) {
							int index = attack.getMylist().getSelectedIndex();
							Unit u = attack.getMyarmy().getUnits().get(index);
							UnitPanelEnemy frame = new UnitPanelEnemy(u);
							// JOptionPane.showMessageDialog(null, "frame");
							view.addBattleUnitFrame(frame);
						}
					});
					attack.getEnemylist().addListSelectionListener(new ListSelectionListener() {

						@Override
						public void valueChanged(ListSelectionEvent e) {
							int index = attack.getEnemylist().getSelectedIndex();
							Unit u = attack.getEnemyarmy().getUnits().get(index);
							UnitPanelEnemy frame = new UnitPanelEnemy(u);
							// JOptionPane.showMessageDialog(null, "frame");
							view.addBattleUnitFrame(frame);
						}
					});
					view.addInfoPanel(attack);
					AttackPanelButton button = new AttackPanelButton(city, a, city1.getDefendingArmy());
					button.addActionListener(this);
					view.getPp().addAttackPanel(button);
					LogPanel lp = new LogPanel(a, city1.getDefendingArmy());
					view.addLog(lp);
					view.getPp().getEndTurn().setEnabled(false);
					view.revalidate();
					view.repaint();
				}
				if (e.getActionCommand().equals("Lay Seige")) {
					//JOptionPane.showMessageDialog(null, "lay1");
					try {
						//JOptionPane.showMessageDialog(null, "lay");
						game.getPlayer().laySiege(a, city1);
					} catch (TargetNotReachedException | FriendlyCityException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						//JOptionPane.showMessageDialog(null, "exc");
					}
				}
			}
		}
//check
		if (info instanceof UnitPanel) {
			UnitPanel u = (UnitPanel) info;
			if (e.getActionCommand().equals("Relocate")) {
				if (relocatedUnit == null) {
					relocatedUnit = u.getUnit();
					JOptionPane.showMessageDialog(null, "Choose an Army to relocate To..Or Click again to Cancell");
				} else {
					relocatedUnit = null;
					JOptionPane.showMessageDialog(null, "Unit Deselected");
				}
			}
			if (e.getActionCommand().equals("Intiate Army")) {
				String c = u.getUnit().getParentArmy().getCurrentLocation();
				// JOptionPane.showMessageDialog(null, c);
				City cit = null;
				for (City city : game.getPlayer().getControlledCities()) {
					if (city.getName().toLowerCase().equals(c.toLowerCase()))
						cit = city;
				}
				game.getPlayer().initiateArmy(cit, u.getUnit());
				view.removeInfoPanel();
			}
		}
		if (info instanceof AttackPanel) {
			AttackPanel ap = (AttackPanel) info;
			if (e.getSource() == ap.getAttack()) {
				int index1 = ap.getMylist().getSelectedIndex();
				int index2 = ap.getEnemylist().getSelectedIndex();
				try {
					game.ManualAttack(ap.getMyarmy(), ap.getEnemyarmy(), index1, index2);
				} catch (FriendlyFireException | MaxCapacityException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}

		PlayerPanel pl = view.getPp();
		if (pl.getEndTurn() == e.getSource()) {
			try {
				// JOptionPane.showMessageDialog(null, "You clicked on ");
				game.endTurn();
			} catch (TargetNotReachedException | FriendlyCityException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return;
		}
		for (AttackPanelButton button : pl.getButtons()) {
			if (button == e.getSource()) {
				AttackPanel attack = new AttackPanel(button.getAttacker(), button.getDefender());
				attack.getAttack().addActionListener(this);
				attack.getMylist().addListSelectionListener(new ListSelectionListener() {
					@Override
					public void valueChanged(ListSelectionEvent e) {
						int index = attack.getMylist().getSelectedIndex();
						Unit u = attack.getMyarmy().getUnits().get(index);
						UnitPanelEnemy frame = new UnitPanelEnemy(u);
						view.addBattleUnitFrame(frame);
					}
				});
				attack.getEnemylist().addListSelectionListener(new ListSelectionListener() {

					@Override
					public void valueChanged(ListSelectionEvent e) {
						int index = attack.getEnemylist().getSelectedIndex();
						Unit u = attack.getEnemyarmy().getUnits().get(index);
						UnitPanelEnemy frame = new UnitPanelEnemy(u);
						view.addBattleUnitFrame(frame);
					}
				});
				view.addInfoPanel(attack);
				LogPanel panel = null;
				for (LogPanel p : view.getLogs()) {
					if (button.getAttacker() == p.getAttacker())
						panel = p;
				}
				view.showLog(panel);
				view.revalidate();
				view.repaint();
				return;
			}
		}
		for (ControlledArmyButton b : view.getCap().getButtons()) {
			if (b == e.getSource()) {
				if (relocatedUnit != null) {
					try {
						b.getArmy().relocateUnit(relocatedUnit);
						JOptionPane.showMessageDialog(null, "Unit relocated");
					} catch (MaxCapacityException e1) {
						JOptionPane.showMessageDialog(null, "Max Capacity");
					}
					relocatedUnit = null;
					return;
				} else {
					ArmyPanel ap = new ArmyPanel(b.getArmy());
					for (JButton button : ap.getButtons()) {
						button.addActionListener(this);
						if(b.getArmy().isShouldAttack()) {
							if (button.getActionCommand().equals("Lay Seige") || button.getActionCommand().equals("Set Target"))
								button.setEnabled(false);
						}
					}
					ap.getList().addListSelectionListener(this);
					// JOptionPane.showMessageDialog(null,"Listner Set");
					view.addInfoPanel(ap);
					view.revalidate();
					view.repaint();
					return;
				}
			}
		}
	}

	public static void main(String[] args) {
		try {
			Controller con = new Controller();
		} catch (IOException | InterruptedException e) {
		}

	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (view.getInfo() instanceof ArmyPanel) {
			// JOptionPane.showMessageDialog(null,"You clicked on");
			ArmyPanel ap = (ArmyPanel) view.getInfo();
			int index = ap.getList().getSelectedIndex();
			Unit u = ap.getArmy().getUnits().get(index);
			UnitPanel panel = new UnitPanel(u);
			view.addInfoPanel(panel);
			panel.getRelocate().addActionListener(this);
			panel.getIntiateArmy().addActionListener(this);
			// JOptionPane.showMessageDialog(null,"Unit panel");
			view.revalidate();
			view.repaint();
		}
	}
}