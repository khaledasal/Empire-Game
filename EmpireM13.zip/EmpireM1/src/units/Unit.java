package units;

import exceptions.FriendlyFireException;
import engine.*;

public abstract class Unit {
	private int level;
	private int maxSoldierCount;
	private int currentSoldierCount;
	private double idleUpkeep;
	private double marchingUpkeep;
	private double siegeUpkeep;
    private Army parentArmy;
    
	public Unit(int level, int maxSoldierConunt, double idleUpkeep, double marchingUpkeep, double siegeUpkeep) {
		this.level = level;
		this.maxSoldierCount = maxSoldierConunt;
		this.idleUpkeep = idleUpkeep;
		this.marchingUpkeep = marchingUpkeep;
		this.siegeUpkeep = siegeUpkeep;
		this.currentSoldierCount=maxSoldierConunt;

	}
	
	public Army getParentArmy() {
		return parentArmy;
	}

	public void setParentArmy(Army parentArmy) {
		this.parentArmy = parentArmy;
	}

	public int getCurrentSoldierCount() {
		return currentSoldierCount;
	}

	public void setCurrentSoldierCount(int currentSoldierCount) {
		if(currentSoldierCount<0)
			this.currentSoldierCount=0;
		else
		this.currentSoldierCount = currentSoldierCount;
	}

	public int getLevel() {
		return level;
	}

	public int getMaxSoldierCount() {
		return maxSoldierCount;
	}

	public double getIdleUpkeep() {
		return idleUpkeep;
	}

	public double getMarchingUpkeep() {
		return marchingUpkeep;
	}

	public double getSiegeUpkeep() {
		return siegeUpkeep;
	}
	
	 public void attack(Unit target) throws FriendlyFireException{
		 if(this.parentArmy == target.parentArmy)
			 throw new FriendlyFireException();
		 int level=this.level;
		 double factor=0.0;
		 if(this instanceof Archer) {
			if(level==1) {
				if(target instanceof Archer) {
					factor=0.3;
				}
				if(target instanceof Infantry) {
					factor=0.2;
				}
				if(target instanceof Cavalry) {
					factor=0.1;
				}
				
			}
			else if (level==2) {
				if(target instanceof Archer) {
					factor=0.4;
				}
				if(target instanceof Infantry) {
					factor=0.3;
				}
				if(target instanceof Cavalry) {
					factor=0.1;
				}
			}
			else if (level==3) {
				if(target instanceof Archer) {
					factor=0.5;
				}
				if(target instanceof Infantry) {
					factor=0.4;
				}
				if(target instanceof Cavalry) {
					factor=0.2;
				}
			}
		 }
		 if(this instanceof Infantry) {
				if(level==1) {
					if(target instanceof Archer) {
						factor=0.3;
					}
					if(target instanceof Infantry) {
						factor=0.1;
					}
					if(target instanceof Cavalry) {
						factor=0.1;
					}
					
				}
				else if (level==2) {
					if(target instanceof Archer) {
						factor=0.4;
					}
					if(target instanceof Infantry) {
						factor=0.2;
					}
					if(target instanceof Cavalry) {
						factor=0.2;
					}
				}
				else if (level==3) {
					if(target instanceof Archer) {
						factor=0.5;
					}
					if(target instanceof Infantry) {
						factor=0.3;
					}
					if(target instanceof Cavalry) {
						factor=0.25;
					}
				}
		 }
		 if(this instanceof Cavalry) {
				if(level==1) {
					if(target instanceof Archer) {
						factor=0.5;
					}
					if(target instanceof Infantry) {
						factor=0.3;
					}
					if(target instanceof Cavalry) {
						factor=0.2;
					}
					
				}
				else if (level==2) {
					if(target instanceof Archer) {
						factor=0.6;
					}
					if(target instanceof Infantry) {
						factor=0.4;
					}
					if(target instanceof Cavalry) {
						factor=0.2;
					}
				}
				else if (level==3) {
					if(target instanceof Archer) {
						factor=0.7;
					}
					if(target instanceof Infantry) {
						factor=0.5;
					}
					if(target instanceof Cavalry) {
						factor=0.3;
					}
				}
		 }
		 target.setCurrentSoldierCount((int)(target.getCurrentSoldierCount()-factor*this.getCurrentSoldierCount()));
		 if(target.getCurrentSoldierCount()<=0) {
			 target.setCurrentSoldierCount(0);
			 target.getParentArmy().handleAttackedUnit(target);
		 }
	 }
	
	
}
