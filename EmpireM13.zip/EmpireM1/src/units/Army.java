package units;

import java.util.ArrayList;

import exceptions.MaxCapacityException;

public class Army{
	private Status currentStatus;
	private ArrayList<Unit> units;
	private int distancetoTarget;
	private String target;
	private String currentLocation;
	private final int maxToHold=10;
	private ArmyListener listener;
	private boolean shouldAttack = false;

	public Army(String currentLocation) {
		this.currentLocation=currentLocation;
		currentStatus=Status.IDLE;
		units=new ArrayList<Unit>();
		distancetoTarget=-1;
		target="";
	}
	public boolean isShouldAttack() {
		return shouldAttack;
	}
	public void setShouldAttack(boolean shouldAttack) {
		this.shouldAttack = shouldAttack;
	}
	public Status getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(Status currentStatus) {
		this.currentStatus = currentStatus;
	}

	public ArrayList<Unit> getUnits() {
		return units;
	}

	public void setUnits(ArrayList<Unit> units) {
		this.units = units;
	}

	public int getDistancetoTarget() {
		return distancetoTarget;
	}

	public void setDistancetoTarget(int distancetoTarget) {
		this.distancetoTarget = distancetoTarget;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
	public int getMaxToHold() {
		return maxToHold;
	}
	
	public void relocateUnit(Unit unit) throws MaxCapacityException{
		if(units.size()==maxToHold)
			throw new  MaxCapacityException();
		Army a= unit.getParentArmy();
		this.getUnits().add(unit);
		a.getUnits().remove(unit);
		unit.setParentArmy(this);
		if(listener!=null) {
			listener.onRelocateUnit(this);
		}
	}
	
	public void handleAttackedUnit(Unit u) {
		if(u.getCurrentSoldierCount()>0)
			return;
		int index = this.getUnits().indexOf(u);
		this.getUnits().remove(u);
		if(listener != null)
			listener.OnHandleAttackedUnit(u,this,index);
	}
	
	public double foodNeeded() {
		double sum=0.0;
		Status s= this.getCurrentStatus();
		for(Unit u:getUnits()) {
			if(s.equals(Status.IDLE))
				 sum+=u.getIdleUpkeep()*u.getCurrentSoldierCount();
			if(s.equals(Status.MARCHING))
				sum+=u.getMarchingUpkeep()*u.getCurrentSoldierCount();
			if(s.equals(Status.BESIEGING))
				sum+=u.getSiegeUpkeep()*u.getCurrentSoldierCount();
		}
		return sum;
	}
	public ArmyListener getListener() {
		return listener;
	}
	public void setListener(ArmyListener listener) {
		this.listener = listener;
	}
	
}
