package units;

public interface ArmyListener {
	void OnHandleAttackedUnit(Unit u, Army a, int index);
	void onRelocateUnit(Army army);
}