package exceptions;

public class UnitFullCapacityException extends ArmyException {

	public UnitFullCapacityException() {
		super();
	}
	
	UnitFullCapacityException(String s){
		super(s);
	}

}
