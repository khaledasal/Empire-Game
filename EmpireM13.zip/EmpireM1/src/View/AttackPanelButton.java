package View;
import java.awt.*;
import javax.swing.*;

import units.Army;


public class AttackPanelButton extends JButton{

	private String currentlocation;
	private Army attacker;
	private Army defender;
	
	public Army getAttacker() {
		return attacker;
	}

	public void setAttacker(Army attacker) {
		this.attacker = attacker;
	}

	public Army getDefender() {
		return defender;
	}

	public void setDefender(Army defender) {
		this.defender = defender;
	}

	public String getCurrentlocation() {
		return currentlocation;
	}

	public void setCurrentlocation(String currentlocation) {
		this.currentlocation = currentlocation;
	}

	public AttackPanelButton(String currentlocation, Army attacker, Army defender) {
		this.attacker=attacker;
		this.defender=defender;
		this.currentlocation=currentlocation;
		this.setText(currentlocation+" Attack Panel");
		
	}

}
