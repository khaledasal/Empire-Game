package View;
import java.awt.*;
import javax.swing.*;
import units.*;

public class ControlledArmyButton extends JButton{
	private Army army;

	public Army getArmy() {
		return army;
	}

	public void setArmy(Army army) {
		this.army = army;
	}

	public ControlledArmyButton(Army army) {
		this.army=army;
	}

}
