package View;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;

import buildings.ArcheryRange;
import engine.*;
import units.*;

public class PlayerPanel extends JPanel {
	private JLabel Player_Name;
	private JLabel TurnsCount;
	private JLabel Gold;
	private JLabel Food;
	private JButton EndTurn;

	public ArrayList<AttackPanelButton> getButtons() {
		return buttons;
	}

	public void setButtons(ArrayList<AttackPanelButton> buttons) {
		this.buttons = buttons;
	}

	private ArrayList<AttackPanelButton> buttons;

	public JLabel getPlayer_Name() {
		return Player_Name;
	}

	public void setPlayer_Name(JLabel player_Name) {
		Player_Name = player_Name;
	}

	public JLabel getTurnsCount() {
		return TurnsCount;
	}

	public void setTurnsCount(JLabel turnsCount) {
		TurnsCount = turnsCount;
	}

	public JLabel getGold() {
		return Gold;
	}

	public void setGold(JLabel gold) {
		Gold = gold;
	}

	public JLabel getFood() {
		return Food;
	}

	public void setFood(JLabel food) {
		Food = food;
	}

	public JButton getEndTurn() {
		return EndTurn;
	}

	public void setEndTurn(JButton endTurn) {
		EndTurn = endTurn;
	}

	public PlayerPanel(String name, double food, double treasury, int turncount) {
		this.setLayout(new FlowLayout(FlowLayout.LEFT));

		buttons = new ArrayList<AttackPanelButton>();
		Player_Name = new JLabel();
		Player_Name.setText("Player's Name: " + name);
		Player_Name.setBackground(Color.BLUE);
		this.add(Player_Name);

		TurnsCount = new JLabel();
		TurnsCount.setText("TurnsCount: " + turncount);
		TurnsCount.setBackground(Color.BLUE);
		this.add(TurnsCount);

		Gold = new JLabel();
		Gold.setText("Treasury: " + treasury);
		Gold.setBackground(Color.BLUE);
		this.add(Gold);

		Food = new JLabel();
		Food.setText("Food:" + food);
		Food.setBackground(Color.BLUE);
		this.add(Food);

		EndTurn = new JButton();
		EndTurn.setText("EndTurn");
		this.add(EndTurn);

	}

	public void addAttackPanel(AttackPanelButton apb) {
		this.add(apb);
		buttons.add(apb);
	}

	public void removeAttackPanel(AttackPanelButton button) {
		this.remove(button);
	}

	public void changeFood(double food) {
		Food.setText("Food: " + food);
	}

	public void changeTreasury(double treasury) {
		Gold.setText("Treasury: " + treasury);
	}

	public void changeTurnsCount(int turnsCount) {
		TurnsCount.setText("TurnsCount: " + turnsCount);
	}

	public static void main(String[] args) {
		Player c = new Player("sara");
		JFrame j = new JFrame();
		j.setBounds(500, 500, 500, 500);
		PlayerPanel p = new PlayerPanel("khaled", 0, 0, 0);
		p.addAttackPanel(new AttackPanelButton("Cairo", new Army("Cairo"), new Army("Sparta")));
		p.changeFood(10);
		p.changeTreasury(10);

		// p.addAttackPanel("ROME");
		// p.removeAttackPanel("Cairo");
		j.add(p);
		j.setVisible(true);

	}

}
