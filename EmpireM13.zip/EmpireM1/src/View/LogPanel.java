package View;
import javax.swing.*;

import units.Army;

import java.awt.*;

public class LogPanel extends JPanel{
	private JLabel log;
	private Army attacker;
	private Army defender;

	public Army getAttacker() {
		return attacker;
	}

	public void setAttacker(Army attacker) {
		this.attacker = attacker;
	}

	public Army getDefender() {
		return defender;
	}

	public void setDefender(Army defender) {
		this.defender = defender;
	}

	public LogPanel(Army attacker,Army defender) {
		this.attacker=attacker;
		this.defender=defender;
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		log=new JLabel("BATTLE LOG : ");
		this.add(log);
		this.add(new JLabel(" "));
	}
	
	public void addLogText(String text) {
		log=new JLabel(text);
		this.add(log);
	}
	
	public static void main(String[] args) {
		JFrame j=new JFrame();
		j.setLayout(new BorderLayout());;
		j.setBounds(0,0,400,400);
		
		LogPanel l=new LogPanel(null,null);
		l.setBackground(Color.BLACK);
		l.setBounds(0, 0, 10, 10);
		JScrollPane scrollPane = new JScrollPane(l);
		//scrollPane.setBounds(500, 500, 500, 500);
		String text="army1 attack army2";
		String text1="kosom el sheikh";
		String text2="khaled el gamed";
		String text3="A7A";
		String tex12="army1 attack army2";
		String text11="kosom el sheikh";
		String text22="khaled el gamed";
		String text33="A7A";
		String text12="army1 attack army2";
		String text23="kosom el sheikh";
		String text24="khaled el gamed";
		String text32="A7A";
		
		l.addLogText(text);
		l.addLogText(text1);
		l.addLogText(text2);
		l.addLogText(text3);
		l.addLogText(text12);
		l.addLogText(text11);
		l.addLogText(text22);
		l.addLogText(text33);
		l.addLogText(text12);
		l.addLogText(text23);
		l.addLogText(text24);
		l.addLogText(text32);
		j.add(scrollPane,BorderLayout.NORTH);
		j.setVisible(true);
		
	}

}
