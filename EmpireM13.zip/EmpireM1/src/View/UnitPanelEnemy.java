package View;
import javax.swing.*;
import java.awt.*;
import units.*;

public class UnitPanelEnemy extends JPanel{
	private JLabel type;
	private JLabel level;
	private JLabel currentsoldiercount;

	public JLabel getType() {
		return type;
	}
	public void setType(JLabel type) {
		this.type = type;
	}
	public JLabel getLevel() {
		return level;
	}
	public void setLevel(JLabel level) {
		this.level = level;
	}
	public JLabel getCurrentsoldiercount() {
		return currentsoldiercount;
	}
	public void setCurrentsoldiercount(JLabel currentsoldiercount) {
		this.currentsoldiercount = currentsoldiercount;
	}
	public UnitPanelEnemy(Unit u) {
		GridBagLayout grid  = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();  
        setLayout(grid); 
		
		if(u instanceof Archer)
			type=new JLabel("Type: Archer");
		if(u instanceof Infantry)
			type=new JLabel("Type: Infantry");
		if(u instanceof Cavalry)
			type=new JLabel("Type: Cavalry");
		level=new JLabel("Level: "+u.getLevel()+"");
		currentsoldiercount=new JLabel("Current Soldier Count: "+u.getCurrentSoldierCount()+"");
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
	    gbc.gridx=0;
	    gbc.gridy=0;
	    this.add(type,gbc);
	    gbc.gridx=0;
	    gbc.gridy=1;
	    this.add(level,gbc);
	    gbc.gridx=0;
	    gbc.gridy=2;
	    this.add(currentsoldiercount,gbc);
		
	}
	public static void main(String[] args) {
		Cavalry c=new Cavalry(3, 40, 5, 4, 3);
		JFrame j=new JFrame();
		UnitPanelEnemy p=new UnitPanelEnemy(c);
		j.add(p);
		j.setVisible(true);
	}

}