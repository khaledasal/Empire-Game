package View ;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.Border;
import buildings.ArcheryRange;
import engine.*;

public class CityPanel extends JPanel {
	private JLabel name;
	private ArrayList<JButton> buttons;
	private City city;
	//JButton intiateArmy;
	
	
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}
	public CityPanel(City city){
		buttons=new ArrayList<JButton>();
		this.city=city;
		this.setBounds(1200,40,800,350);
		
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));   
        
        name=new JLabel(city.getName());
        name.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.add(name);


        JButton farm=new JButton("Farm");  
        farm.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.add(farm);
        buttons.add(farm);

        JButton archeryrange=new JButton("Archery Range");  
        archeryrange.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.add(archeryrange);
        buttons.add(archeryrange);

        JButton barracks=new JButton("Barraks");  
        barracks.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.add(barracks);
        buttons.add(barracks);

        JButton stable =new JButton("Stable"); 
        stable.setAlignmentX(Component.CENTER_ALIGNMENT);     
        this.add(stable);
        buttons.add(stable);

	    JButton market =new JButton("Market");
	    market.setAlignmentX(Component.CENTER_ALIGNMENT);
		this.add(market); 
		buttons.add(market);
		
		JButton army =new JButton("Army");
		army.setAlignmentX(Component.CENTER_ALIGNMENT);
		this.add(army); 
		buttons.add(army);
		 
	}
	public JLabel getName1() {
		return name;
	}
	public void setName(JLabel name) {
		this.name = name;
	}
	
	public ArrayList<JButton> getButtons() {
		return buttons;
	}
	public void setButtons(ArrayList<JButton> buttons) {
		this.buttons = buttons;
	}
	
	public static void main(String[] args) {
		City c=new City("Cairo");
		JFrame j=new JFrame();
		j.setBounds(500, 500, 500, 500);
		CityPanel p=new CityPanel(c);
		j.add(p);
		j.setVisible(true);
	}
	
}
