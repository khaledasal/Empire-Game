package View;

import java.util.ArrayList;

import javax.swing.*;

import buildings.Farm;

import java.awt.*;
import engine.*;
import units.Army;
import units.Cavalry;

public class View extends JFrame{
	private ArrayList<CityView> MyCities;
	private JPanel info;
	private ContolledArmyPanel cap;
	private ArrayList<LogPanel> logs;
	private LogPanel currentlog;
	private PlayerPanel pp;
	

	public PlayerPanel getPp() {
		return pp;
	}

	public void setPp(PlayerPanel pp) {
		this.pp = pp;
	}

	public ContolledArmyPanel getCap() {
		return cap;
	}

	public ArrayList<LogPanel> getLogs() {
		return logs;
	}

	public void setLogs(ArrayList<LogPanel> logs) {
		this.logs = logs;
	}

	public void setCap(ContolledArmyPanel cap) {
		this.cap = cap;
	}

	public JPanel getInfo() {
		return info;
	}

	public void setInfo(JPanel info) {
		this.info = info;
	}

	public ArrayList<CityView> getMyCities() {
		return MyCities;
	}

	public void setMyCities(ArrayList<CityView> myCities) {
		MyCities = myCities;
	}
	
	public View(String name,ArrayList<City>city,double food, double t) {
		this.setBounds(0, 0, 2000, 800);
		this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Build Your Empire");
		pp=new PlayerPanel(name, food, t, 1);
		pp.setBackground(Color.blue);	
        pp.setBounds(0, 0,2000, 40);
        this.add(pp,BorderLayout.NORTH);
		this.setVisible(true);
		
		//addInfoPanel(new EconomicBuildingPanel(new Farm(),true,""));
		
		JPanel worldmap=new JPanel();
		worldmap.setLayout(null);
		worldmap.setBackground(Color.CYAN);
		MyCities=new ArrayList<CityView>();
		City c1=city.get(0);
		CityView cv1=new CityView(c1);
		City c2=city.get(1);
		CityView cv2=new CityView(c2);
		City c3=city.get(2);
		CityView cv3= new CityView(c3);
		MyCities.add(cv3);
		MyCities.add(cv2);
		MyCities.add(cv1);
	    worldmap.setBounds(0, 40,1200,650);
	    cv1.setBounds(100, 400, 100, 100);
	    cv2.setBounds(1000, 200, 100, 100);
	    cv3.setBounds(400, 150, 100, 100);
	    worldmap.add(cv1);
	    worldmap.add(cv2);
	    worldmap.add(cv3);
	    this.add(worldmap,BorderLayout.CENTER);
	    
	    logs=new ArrayList<LogPanel>();
	    cap=new ContolledArmyPanel();
	    this.addControlledArmyPanel(cap);
	}
	
	public void addLog(LogPanel p) {
		if(p==null)
			return;
		logs.add(p);
		showLog(p);
	}
	
	public void showLog(LogPanel p) {
		if(p==null)
			return;
		if(currentlog!=null) {
			this.removeLog(currentlog);
		}
		p.setBounds(1200,390,80,30);
		
		JScrollPane scrollableTextArea = new JScrollPane(p);
        int horizontalPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        int vericalPolicy = JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED;
        scrollableTextArea.setHorizontalScrollBarPolicy(horizontalPolicy);
        scrollableTextArea.setVerticalScrollBarPolicy(vericalPolicy);
		p.setBackground(Color.BLACK);
		scrollableTextArea.setMaximumSize(new Dimension(100, p.getHeight()));
		JScrollPane jScrollPane = new JScrollPane(p);
		jScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        jScrollPane.setMaximumSize(new Dimension(1000, 50));
        jScrollPane.setPreferredSize(new Dimension(0, 50));
        jScrollPane.setVisible(true);
        //JScrollPane scrollPane = new JScrollPane(this.makeMainInnerPanel());
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setVisible(true);
        mainPanel.add(jScrollPane);
		
		this.add(p,BorderLayout.WEST);
		this.setVisible(true);
		currentlog=p;
		this.revalidate();
		this.repaint();
	}
	
	public void removeLog(LogPanel p){
		if(p==null)
			return;
		logs.remove(p);
		this.remove(p);
	}
	
	
	public void addControlledArmyPanel(ContolledArmyPanel p) {
		if(p==null)
			return;
		cap=p;
		cap.setBounds(0,690,2000,40);
		//cap.setBackground(Color.green);
		
		this.add(cap,BorderLayout.SOUTH);
		this.setVisible(true);
	}
	
	public void removeControlledArmyPanel() {
		this.remove(cap);
	}
	
	public void addInfoPanel(JPanel j) {
		if(j==null)
			return;
		removeInfoPanel();
		j.setBounds(1200,40,800,350);
		info=j;
		//info.setLayout(null);
		info.setBackground(Color.BLUE);
        
        
        //
        JScrollPane scrollableTextArea = new JScrollPane(info);
        int horizontalPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        int vericalPolicy = JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED;
        scrollableTextArea.setHorizontalScrollBarPolicy(horizontalPolicy);
        scrollableTextArea.setVerticalScrollBarPolicy(vericalPolicy);
        //
        
		info.setBounds(1200,40,800,350);
		this.add(j,BorderLayout.EAST);
		this.setVisible(true);
		this.revalidate();
		getContentPane().revalidate();
		getContentPane().repaint();
	}
	
	public void removeInfoPanel() {
		if(info==null)
			return;
		this.remove(info);
		this.info=null;
	}
	
	public void addBattleUnitFrame(UnitPanelEnemy e) {
		JFrame j=new JFrame();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		j.setBounds(1000, 40, 200,200);
		j.add(e);
		j.setVisible(true);
	}
	
	
	public static void main(String[] args) {
		City c=new City("Cairo");
		City c1=new City("Cairo1");
		City c2=new City("Cairo2");
		ArrayList<City>city=new ArrayList<City>();
		city.add(c);
		city.add(c1);
		city.add(c2);
		View v=new View("khaled",city,10,5);
	    v.revalidate();
	    v.repaint();
	    v.cap.addControlledArmyButton(new Army("tanta"));
	    LogPanel l = new LogPanel(new Army("tanta"), new Army("mahala"));
	    v.addLog(l);
	    int x = 0;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    l.addLogText("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ x);
	    x++;
	    
	    v.addInfoPanel(new AttackPanel(new Army("tanta"), new Army("mahala")));
	    v.revalidate();
	}
	
}
