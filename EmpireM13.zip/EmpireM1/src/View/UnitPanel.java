package View;

import javax.swing.*;
import java.awt.*;
import units.*;

public class UnitPanel extends JPanel{
	private JLabel type;
	private JLabel level;
	private JLabel currentsoldiercount;
	private JLabel maxsoldiercount;;
	private JButton relocate;
	private JButton intiateArmy;
	private Unit unit;
	
	public JLabel getType() {
		return type;
	}
	public void setType(JLabel type) {
		this.type = type;
	}
	public JLabel getLevel() {
		return level;
	}
	public void setLevel(JLabel level) {
		this.level = level;
	}
	public JLabel getCurrentsoldiercount() {
		return currentsoldiercount;
	}
	public void setCurrentsoldiercount(JLabel currentsoldiercount) {
		this.currentsoldiercount = currentsoldiercount;
	}
	public JLabel getMaxsoldiercount() {
		return maxsoldiercount;
	}
	public void setMaxsoldiercount(JLabel maxsoldiercount) {
		this.maxsoldiercount = maxsoldiercount;
	}
	public JButton getRelocate() {
		return relocate;
	}
	public void setRelocate(JButton relocate) {
		this.relocate = relocate;
	}
	public JButton getIntiateArmy() {
		return intiateArmy;
	}
	public void setIntiateArmy(JButton intiateArmy) {
		this.intiateArmy = intiateArmy;
	}
	public UnitPanel(Unit u){
		this.unit=u;
		GridBagLayout grid  = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();  
        setLayout(grid); 
		
		if(u instanceof Archer)
			type=new JLabel("Type: Archer");
		if(u instanceof Infantry)
			type=new JLabel("Type: Infantry");
		if(u instanceof Cavalry)
			type=new JLabel("Type: Cavalry");
		level=new JLabel("Level: "+u.getLevel()+"");
		currentsoldiercount=new JLabel("Current Soldier Count: "+u.getCurrentSoldierCount()+"");
		maxsoldiercount=new JLabel("Max Soldier Count: "+u.getMaxSoldierCount());
	
		relocate=new JButton("Relocate");
		intiateArmy=new JButton("Intiate Army");
		
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
	    gbc.gridx=0;
	    gbc.gridy=0;
	    this.add(type,gbc);
	    gbc.gridx=0;
	    gbc.gridy=1;
	    this.add(level,gbc);
	    gbc.gridx=0;
	    gbc.gridy=2;
	    this.add(currentsoldiercount,gbc);
	    gbc.gridx=0;
	    gbc.gridy=3;
		this.add(maxsoldiercount,gbc);
	    gbc.gridx=0;
	    gbc.gridy=4;
	    gbc.gridwidth=1;
	    gbc.fill=GridBagConstraints.NONE;
		this.add(relocate,gbc);
		gbc.gridx=1;
	    gbc.gridy=4;
		this.add(intiateArmy,gbc);
		
		
		
	}
	public Unit getUnit() {
		return unit;
	}
	public void setUnit(Unit unit) {
		this.unit = unit;
	}
	
	public static void main(String[] args) {
		Cavalry c=new Cavalry(3, 40, 5, 4, 3);
		JFrame j=new JFrame();
		UnitPanel p=new UnitPanel(c);
		j.add(p);
		j.setVisible(true);
	}

}
