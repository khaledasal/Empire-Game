package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import engine.City;
import engine.Distance;

public class GameIntro extends JFrame implements ActionListener {
	JLabel label1;
	JLabel label2;
	JTextField text;
	private JButton button;
	public JButton getButton() {
		return button;
	}
	public void setButton(JButton button) {
		this.button = button;
	}
	JComboBox jcb;
	private String PlayerName;
	private String CityName;
	
	public GameIntro() throws IOException{
		label1= new JLabel("please enter your name");
		label2=new JLabel("please choose your city");
		text = new JTextField();
		text.addActionListener(this);
		button = new JButton();
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) { 
	             synchronized (button) {
	            	 if(PlayerName==null) {
		            	 JOptionPane.showMessageDialog(null,"Enter Your Name..");
		            	 return;
		             }
		             if(CityName==null) {
		            	 JOptionPane.showMessageDialog(null,"Choose Your City..");
		            	 return;
		             }
	                 button.notify();
	             } 
	    } 
		});
		String [] names = loadCitiesAndDistances();
		 jcb = new JComboBox(names);
		 jcb.addActionListener(this);
		 button.setText("Start The Game");
		 button.setBackground(Color.BLUE);
		 button.setForeground(Color.WHITE);
		 button.setBounds(330, 380, 150, 50);
		 
		label1.setBounds(10, 50, 150, 20);
		label1.setBackground(Color.BLUE);
		label1.setForeground(Color.WHITE);
		label1.setOpaque(true);
		label2.setBounds(10, 130, 200, 20);
		label2.setBackground(Color.BLUE);
		label2.setForeground(Color.WHITE);
		label2.setOpaque(true);
		
		jcb.setBounds(10, 150, 200, 80);
		
		text.setBounds(10,70, 150, 20);
		Font labelFont = label1.getFont();
		String labelText = label1.getText();
		Font label2Font = label2.getFont();
		String label2Text = label2.getText();

		int stringWidth = label1.getFontMetrics(labelFont).stringWidth(labelText);
		int componentWidth = label1.getWidth();
		int stringWidth2 = label2.getFontMetrics(label2Font).stringWidth(label2Text);
		int componentWidth2 = label2.getWidth();

		// Find out how much the font can grow in width.
		double widthRatio = (double)componentWidth / (double)stringWidth;
		double widthRatio2 = (double)componentWidth2 / (double)stringWidth2;

		int newFontSize = (int)(labelFont.getSize() * widthRatio);
		int newFontSize2 = (int)(label2Font.getSize() * widthRatio2);
		int componentHeight = label1.getHeight();
		int componentHeight2 = label2.getHeight();
		// Pick a new font size so it will not be larger than the height of label.
		int fontSizeToUse = Math.min(newFontSize, componentHeight);
		int fontSizeToUse2 = Math.min(newFontSize2, componentHeight2);

		// Set the label's font size to the newly determined size.
		label1.setFont(new Font(labelFont.getName(), Font.PLAIN, fontSizeToUse));
		label2.setFont(new Font(label2Font.getName(), Font.PLAIN, fontSizeToUse2));
		setBounds(200, 40, 500, 500);
		setTitle("Intro");
		getContentPane().setBackground(Color.BLACK);
		setLayout(null);
		getContentPane().add(label1);
		getContentPane().add(label2);
		getContentPane().add(text);
		 getContentPane().add(jcb);
		getContentPane().add(button);
	}
	public String getPlayerName() {
		return PlayerName;
	}
	public String getCityName() {
		return CityName;
	}
	private String[] loadCitiesAndDistances() throws IOException {

		BufferedReader br = new BufferedReader(new FileReader("distances.csv"));
		String currentLine = br.readLine();
		ArrayList<String> names = new ArrayList<String>();

		while (currentLine != null) {

			String[] content = currentLine.split(",");
			if (!names.contains(content[0])) {
				names.add(content[0]);
			} else if (!names.contains(content[1])) {
				names.add(content[1]);
			}
			currentLine = br.readLine();
		}
		br.close();
		String [] ayhaga= new String [names.size()];
		int i = 0;
		for (String name : names){
			ayhaga[i] = name;
			i++;
			
		}
		return ayhaga;
	}
	
	public static void main(String[] args) throws IOException {
		GameIntro m = new GameIntro ();
		m.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==text) {
		String textFieldValue = text.getText();
		this.PlayerName=textFieldValue;
		//JOptionPane.showMessageDialog(null,"You clicked on "+textFieldValue);
		}
		if(e.getSource()==jcb) {
		String x = String.valueOf(jcb.getSelectedItem());
		this.CityName=x;
		//JOptionPane.showMessageDialog(null,"You clicked on "+x);
		}
	}

}
