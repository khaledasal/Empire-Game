package View;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.ConcurrentHashMap.KeySetView;

import buildings.*;
import buildings.*;
public class EconomicBuildingPanel extends JPanel{
	private JLabel cost;
	private JLabel upgradecost;
	private JLabel type;
	private JLabel level;
	private JLabel cooldown;
	//JLabel recruitmentcost;
	//JLabel maxrecruit;
	//JLabel currentrecruit;
	private JButton upgrade;
	private JButton Build;
	private EconomicBuilding EM;
	private String Type1;
	private EconomicBuilding typeB;

	public EconomicBuilding getTypeB() {
		return typeB;
	}

	public void setTypeB(EconomicBuilding typeB) {
		this.typeB = typeB;
	}

	public String getType1() {
		return Type1;
	}

	public void setType1(String type1) {
		Type1 = type1;
	}

	public EconomicBuilding getEM() {
		return EM;
	}

	public void setEM(EconomicBuilding eM) {
		EM = eM;
	}

	public JLabel getCost() {
		return cost;
	}

	public void setCost(JLabel cost) {
		this.cost = cost;
	}

	public JLabel getUpgradecost() {
		return upgradecost;
	}

	public void setUpgradecost(JLabel upgradecost) {
		this.upgradecost = upgradecost;
	}

	public JLabel getType() {
		return type;
	}

	public void setType(JLabel type) {
		this.type = type;
	}

	public JLabel getLevel() {
		return level;
	}

	public void setLevel(JLabel level) {
		this.level = level;
	}

	public JLabel getCooldown() {
		return cooldown;
	}

	public void setCooldown(JLabel cooldown) {
		this.cooldown = cooldown;
	}

	public JButton getUpgrade() {
		return upgrade;
	}

	public void setUpgrade(JButton upgrade) {
		this.upgrade = upgrade;
	}

	public JButton getBuild() {
		return Build;
	}

	public void setBuild(JButton build) {
		Build = build;
	}

	public EconomicBuildingPanel(EconomicBuilding e,boolean built, EconomicBuilding a) {
		this.typeB=a;
		this.EM=e;
		GridBagLayout grid  = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();  
        setLayout(grid); 
        
        if(built) {
        
		cost =new JLabel("Cost: " +e.getCost()+"");
		if(e instanceof Market)
			type=new JLabel("Type: Market");
		else if(e instanceof Farm)
			type=new JLabel("Type : Farm");
		level= new JLabel("Level: "+e.getLevel()+"");
		if (e.isCoolDown())
			cooldown=new JLabel("Cooling Down: YES ");
		else if(!e.isCoolDown())
			cooldown=new JLabel("Cooling Down: NO ");
		upgradecost=new JLabel("Upgrade Cost: "+e.getUpgradeCost()+"");
		upgrade=new JButton("Upgrade");
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=0;
		this.add(type,gbc);
		gbc.gridx=0;
		gbc.gridy=1;
		this.add(cost,gbc);
		gbc.gridx=0;
		gbc.gridy=2;
		this.add(upgradecost,gbc);
		gbc.gridx=0;
		gbc.gridy=3;
		this.add(level,gbc);
		gbc.gridx=0;
		gbc.gridy=4;
		this.add(cooldown,gbc);
		gbc.gridx=0;
		gbc.gridy=5;
		this.add(upgrade,gbc);
        }
        
        else {
        	cost =new JLabel("Cost: " +a.getCost()+"");
        	Build=new JButton("Build");
        	gbc.gridwidth=GridBagConstraints.REMAINDER;
    	    gbc.fill=GridBagConstraints.HORIZONTAL;
    	    gbc.gridx=0;
    		gbc.gridy=0;
    		this.add(cost,gbc);
    		gbc.gridx=0;
    		gbc.gridy=1;
    		this.add(Build,gbc);	
        }
	}
}
