package View;
import javax.swing.*;
import java.util.ArrayList;

import buildings.ArcheryRange;

import java.awt.*;
import units.*;

public class ArmyPanel extends JPanel{
	private JList list;
	private JLabel currentstatus;
	private JLabel target;
	private JLabel distancetotarget;
	private JLabel location;
	private JLabel units;
	private JLabel Battleoptions;
	private ArrayList<JButton> buttons;
	private ArrayList<String> unitsName;
	
	
	public ArrayList<String> getUnitsName() {
		return unitsName;
	}

	public void setUnitsName(ArrayList<String> unitsName) {
		this.unitsName = unitsName;
	}

	public JLabel getTarget() {
		return target;
	}

	public void setTarget(JLabel target) {
		this.target = target;
	}

	public ArrayList<JButton> getButtons() {
		return buttons;
	}

	public void setButtons(ArrayList<JButton> buttons) {
		this.buttons = buttons;
	}

	private Army army;

	public JList getList() {
		return list;
	}

	public void setList(JList list) {
		this.list = list;
	}

	public ArmyPanel(Army a) {
		buttons=new ArrayList<JButton>();
		this.army=a;
		ArrayList<String> unitsName = new ArrayList<String>();
		this.unitsName=unitsName;
		int archerindex=1;
		int cavlaryindex=1;
		int infantryindex=1;
		for(Unit u:a.getUnits()) {
			if(u instanceof Archer) {
				unitsName.add("Archer"+archerindex+"");
				archerindex++;
			}
			if(u instanceof Cavalry) {
				unitsName.add("Cavalry"+cavlaryindex+"");
				cavlaryindex++;
			}
			if(u instanceof Infantry) {
				unitsName.add("Infantry"+infantryindex+"");
				infantryindex++;
			}
		}
		String[] s=new String[a.getUnits().size()];
		int i = 0;
		for(String unit:unitsName) {
			s[i]=unit;
			i++;
		}
		GridBagLayout grid  = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();  
        setLayout(grid);
		
		list = new JList(s); 
		//list.addListSelectionListener(this);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		list.setVisibleRowCount(-1);
		JScrollPane listScroller = new JScrollPane(list);
		listScroller.setPreferredSize(new Dimension(250, 80));
		
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
	    
		currentstatus=new JLabel("Current Status: "+a.getCurrentStatus()+"");
		
		if(a.getTarget().equals("")||a.getTarget()==null) {
		}
		else {
			target=new JLabel("Target: "+a.getTarget());
			distancetotarget=new JLabel("Distance To Target: "+a.getDistancetoTarget()+"");
			gbc.gridx=0;
			gbc.gridy=0;
			this.add(target,gbc);
			gbc.gridx=0;
			gbc.gridy=1;
			this.add(distancetotarget,gbc);
		}
		
		
		
		location=new JLabel("Current Location: "+a.getCurrentLocation()+"");
		gbc.gridx=0;
		gbc.gridy=2;
		this.add(currentstatus,gbc);
		gbc.gridx=0;
		gbc.gridy=3;
	    this.add(location,gbc);
	    gbc.gridx=0;
		gbc.gridy=4;
		units=new JLabel("Units: ");
		gbc.gridx=0;
		gbc.gridy=5;
		this.add(units,gbc);
		 gbc.gridwidth=1;
		    gbc.fill=GridBagConstraints.VERTICAL;
		gbc.gridx=0;
		gbc.gridy=6;
	    this.add(list,gbc);
	    
	    gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
	    
	    JButton settarget=new JButton("Set Target");
	    JButton Autoresolve=new JButton("Auto Resolve");
		JButton manual=new JButton("Manual");
	    JButton layseige=new JButton("Lay Seige");
	    
	    gbc.gridx=0;
		gbc.gridy=7;
	    Battleoptions=new JLabel("Battle Options: ");
	    this.add(Battleoptions,gbc);
	    
	    gbc.gridwidth=1;
	    gbc.fill=GridBagConstraints.NONE;
	    
	    gbc.gridx=0;
		gbc.gridy=8;
	    this.add(Autoresolve,gbc);
	    buttons.add(Autoresolve);
	    
	    manual=new JButton("Manual");
	    gbc.gridx=1;
		gbc.gridy=8;
	    this.add(manual,gbc);
	    buttons.add(manual);
	    
	    gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
	    gbc.gridx=0;
		gbc.gridy=9;
	    this.add(layseige,gbc);
	    buttons.add(layseige);
	    gbc.gridx=0;
		gbc.gridy=10;
		this.add(settarget,gbc);
	    buttons.add(settarget);
		
		
	}
	
	public Army getArmy() {
		return army;
	}

	public void setArmy(Army army) {
		this.army = army;
	}

	public static void main(String[] args) {
		Archer a=new Archer(2, 30, 4, 5, 3);
		Cavalry c=new Cavalry(2,30,5,3,2);
		Archer b=new Archer(3, 30, 4, 5, 3);
		Army x=new Army("Tanta");
		x.setCurrentStatus(Status.MARCHING);
		x.getUnits().add(a);
		x.getUnits().add(c);
		x.getUnits().add(b);
		JFrame j=new JFrame();
		ArmyPanel y=new ArmyPanel(x);
		j.add(y);
		j.setVisible(true);
				
	}

}
