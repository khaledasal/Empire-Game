package View;

import java.awt.*;
import java.security.DomainCombiner;

import javax.swing.*;
import buildings.*;
import exceptions.BuildingInCoolDownException;
import exceptions.MaxRecruitedException;
import units.Unit;

public class MilitaryBuildingPanel extends JPanel{
	private JLabel cost;
	private JLabel upgradecost;
	private JLabel type;
	private JLabel level;
	private JLabel cooldown;
	private JLabel recruitmentcost;
	private JLabel maxrecruit;
	private JLabel currentrecruit;
	private JButton upgrade;
	private JButton Build;
	private MilitaryBuilding typeB; 
	public MilitaryBuilding getTypeB() {
		return typeB;
	}
	public void setTypeB(MilitaryBuilding typeB) {
		this.typeB = typeB;
	}
	public MilitaryBuilding getMB() {
		return MB;
	}
	public void setMB(MilitaryBuilding mB) {
		MB = mB;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	private JButton recruit;
	private MilitaryBuilding MB;
	private String type1;
	
	
	public JLabel getCost() {
		return cost;
	}
	public void setCost(JLabel cost) {
		this.cost = cost;
	}
	public JLabel getUpgradecost() {
		return upgradecost;
	}
	public void setUpgradecost(JLabel upgradecost) {
		this.upgradecost = upgradecost;
	}
	public JLabel getType() {
		return type;
	}
	public void setType(JLabel type) {
		this.type = type;
	}
	public JLabel getLevel() {
		return level;
	}
	public void setLevel(JLabel level) {
		this.level = level;
	}
	public JLabel getCooldown() {
		return cooldown;
	}
	public void setCooldown(JLabel cooldown) {
		this.cooldown = cooldown;
	}
	public JLabel getRecruitmentcost() {
		return recruitmentcost;
	}
	public void setRecruitmentcost(JLabel recruitmentcost) {
		this.recruitmentcost = recruitmentcost;
	}
	public JLabel getMaxrecruit() {
		return maxrecruit;
	}
	public void setMaxrecruit(JLabel maxrecruit) {
		this.maxrecruit = maxrecruit;
	}
	public JLabel getCurrentrecruit() {
		return currentrecruit;
	}
	public void setCurrentrecruit(JLabel currentrecruit) {
		this.currentrecruit = currentrecruit;
	}
	public JButton getUpgrade() {
		return upgrade;
	}
	public void setUpgrade(JButton upgrade) {
		this.upgrade = upgrade;
	}
	public JButton getBuild() {
		return Build;
	}
	public void setBuild(JButton build) {
		Build = build;
	}
	public JButton getRecruit() {
		return recruit;
	}
	public void setRecruit(JButton recruit) {
		this.recruit = recruit;
	}
	public MilitaryBuildingPanel(MilitaryBuilding e,boolean built,MilitaryBuilding a){
		this.typeB=a;
		this.MB=e;
		GridBagLayout grid  = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();  
        setLayout(grid); 
        
        if(built) {
        
		cost =new JLabel("Cost: " +e.getCost()+"");
		
		if(e instanceof ArcheryRange)
			type=new JLabel("Type: ArcherRange");
		else if(e instanceof Barracks )
			type=new JLabel("Type : Barracks");
		else if (e instanceof Stable)
			type= new JLabel("Type: Stable");

		level= new JLabel("Level: "+e.getLevel()+"");
		
		if (e.isCoolDown())
			cooldown=new JLabel("Cooling Down: YES ");
		else if(!e.isCoolDown())
			cooldown=new JLabel("Cooling Down: NO ");
		
		upgradecost=new JLabel("Upgrade Cost: "+e.getUpgradeCost()+"");
		upgrade=new JButton("Upgrade");
		recruitmentcost=new JLabel("Recruitment Cost: "+e.getRecruitmentCost()+"");
		maxrecruit =new JLabel("Max Recruit: "+e.getMaxRecruit()+"");
		currentrecruit=new JLabel("Current Recruit: "+e.getCurrentRecruit()+"");
		recruit=new JButton("Recruit");
		
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=0;
		this.add(type,gbc);
		gbc.gridx=0;
		gbc.gridy=1;
		this.add(cost,gbc);
		gbc.gridx=0;
		gbc.gridy=2;
		this.add(upgradecost,gbc);
		gbc.gridx=0;
		gbc.gridy=3;
		this.add(level,gbc);
		gbc.gridx=0;
		gbc.gridy=4;
		this.add(cooldown,gbc);
		gbc.gridx=0;
		gbc.gridy=5;
		this.add(currentrecruit,gbc);
		gbc.gridx=0;
		gbc.gridy=6;
		this.add(maxrecruit,gbc);
		gbc.gridx=0;
		gbc.gridy=7;
		this.add(recruitmentcost,gbc);
		gbc.gridx=0;
		gbc.gridy=8;
		gbc.gridwidth=1;
	    gbc.fill=GridBagConstraints.NONE;
		this.add(upgrade,gbc);
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=1;
		gbc.gridy=8;
		this.add(recruit,gbc);
	    
        }
        
        else {
        	cost =new JLabel("Cost: " +a.getCost()+"");
        	Build=new JButton("Build");
        	gbc.gridwidth=GridBagConstraints.REMAINDER;
    	    gbc.fill=GridBagConstraints.HORIZONTAL;
    	    gbc.gridx=0;
    		gbc.gridy=0;
    		this.add(cost,gbc);
    		gbc.gridx=0;
    		gbc.gridy=1;
    		this.add(Build,gbc);
    		
        	
        }    
	}
	
	public void setCurrentRecruit() {
		currentrecruit.setText("Current Recruit: "+MB.getCurrentRecruit()+"");
	}
	
	public static void main(String[] args) {
		Barracks b=new Barracks();
		JFrame j=new JFrame();
		//MilitaryBuildingPanel v=new MilitaryBuildingPanel(b,true);
		//j.add(v);
		j.setVisible(true);
	}
}
