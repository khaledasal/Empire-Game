package View;
import javax.swing.*;
import java.awt.*;
import engine.*;

public class CityView extends JButton{
	
	private City thisCity;

	public City getThisCity() {
		return thisCity;
	}

	public void setThisCity(City thisCity) {
		this.thisCity = thisCity;
	}

	public CityView (City c){
		thisCity=c;
		this.setText(c.getName());
	}

}
