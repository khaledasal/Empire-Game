package View;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import engine.*;
import units.*;

public class AttackPanel extends JPanel{
	private JLabel units;
	private String[] mylistString;
	private JList mylist;
	private String[] enemylistString;
	private JList enemylist;
	private Army myarmy;
	private Army enemyarmy;
	private JButton attack;
	
	public JButton getAttack() {
		return attack;
	}

	public String[] getMylistString() {
		return mylistString;
	}

	public void setMylistString(String[] mylistString) {
		this.mylistString = mylistString;
	}

	public String[] getEnemylistString() {
		return enemylistString;
	}

	public void setEnemylistString(String[] enemylistString) {
		this.enemylistString = enemylistString;
	}

	public void setAttack(JButton attack) {
		this.attack = attack;
	}

	public Army getMyarmy() {
		return myarmy;
	}

	public JList getMylist() {
		return mylist;
	}

	public void setMylist(JList mylist) {
		this.mylist = mylist;
	}

	public JList getEnemylist() {
		return enemylist;
	}

	public void setEnemylist(JList enemylist) {
		this.enemylist = enemylist;
	}

	public void setMyarmy(Army myarmy) {
		this.myarmy = myarmy;
	}

	public Army getEnemyarmy() {
		return enemyarmy;
	}

	public void setEnemyarmy(Army enemyarmy) {
		this.enemyarmy = enemyarmy;
	}

	public JLabel getUnits() {
		return units;
	}

	public void setUnits(JLabel units) {
		this.units = units;
	}

	public AttackPanel(Army myarmy,Army enemyarmy) {
		this.myarmy=myarmy;
		this.enemyarmy=enemyarmy;
		
		GridBagLayout grid  = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();  
        setLayout(grid);
        gbc.gridwidth=GridBagConstraints.NONE;
	    gbc.fill=GridBagConstraints.VERTICAL;
		
		String[] s =new String[myarmy.getUnits().size()];
		this.mylistString=s;
		mylist = new JList(s); 
		mylist.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		mylist.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		mylist.setVisibleRowCount(-1);
		JScrollPane listScroller = new JScrollPane(mylist);
		listScroller.setPreferredSize(new Dimension(250, 80));
		
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
		units=new JLabel("My Units: ");
		gbc.gridx=0;
		gbc.gridy=0;
		this.add(units,gbc);
		
		int archerindex=1;
		int cavlaryindex=1;
		int infantryindex=1;
		int i=0;
		for(Unit u:myarmy.getUnits()) {
			if(u instanceof Archer) {
				s[i]="Archer"+archerindex+"";
				archerindex++;
				i++;
			}
			if(u instanceof Cavalry) {
				s[i]="Cavalry"+cavlaryindex+"";
				cavlaryindex++;
				i++;
			}
			if(u instanceof Infantry) {
				s[i]="Infantry"+infantryindex+"";
				infantryindex++;
				i++;
			}
		}
		
		gbc.gridwidth=1;
	    gbc.fill=GridBagConstraints.NONE;
		gbc.gridx=0;
		gbc.gridy=1;
		this.add(mylist,gbc);
		
		String[] s1 =new String[enemyarmy.getUnits().size()];
		this.enemylistString=s1;
		enemylist = new JList(s1);
		enemylist.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		enemylist.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		enemylist.setVisibleRowCount(-1);
		JScrollPane listScroller1 = new JScrollPane(enemylist);
		listScroller1.setPreferredSize(new Dimension(250, 80));
		
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
		units=new JLabel("Enemy Units: ");
		gbc.gridx=0;
		gbc.gridy=2;
		this.add(units,gbc);
		
		int archerindex1=1;
		int cavlaryindex1=1;
		int infantryindex1=1;
		int i1=0;
		for(Unit u:enemyarmy.getUnits()) {
			if(u instanceof Archer) {
				s1[i1]="Archer"+archerindex1+"";
				archerindex1++;
				i1++;
			}
			if(u instanceof Cavalry) {
				s1[i1]="Cavalry"+cavlaryindex1+"";
				cavlaryindex1++;
				i1++;
			}
			if(u instanceof Infantry) {
				s1[i1]="Infantry"+infantryindex1+"";
				infantryindex1++;
				i1++;
			}
		}
		
		gbc.gridwidth=1;
	    gbc.fill=GridBagConstraints.NONE;
		gbc.gridx=0;
		gbc.gridy=3;
		this.add(enemylist,gbc);
		
		gbc.gridwidth=GridBagConstraints.REMAINDER;
	    gbc.fill=GridBagConstraints.HORIZONTAL;
	    attack=new JButton("Attack");
		gbc.gridx=0;
		gbc.gridy=4;
		this.add(attack,gbc);
	    
		
		
	}
	
	 public static void main(String[] args) {
		Army x=new Army("Cairo");
		
		Cavalry c=new Cavalry(2,30,5,3,2);
		Archer b=new Archer(3, 30, 4, 5, 3);
		x.getUnits().add(c);
		x.getUnits().add(b);
		Army y=new Army("Tanta");;
		y.getUnits().add(c);
		y.getUnits().add(b);
		JFrame j=new JFrame();
		AttackPanel z=new AttackPanel(x,y);
		j.add(z);
		j.setVisible(true);
		
	}

}
