package View;
import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import units.*;

public class ContolledArmyPanel extends JPanel{
	ArrayList<ControlledArmyButton> buttons;
	
	public ContolledArmyPanel() {
		buttons=new ArrayList<ControlledArmyButton>();
		this.setLayout(new FlowLayout(FlowLayout.LEFT));
	}

	public ArrayList<ControlledArmyButton> getButtons() {
		return buttons;
	}

	public void setButtons(ArrayList<ControlledArmyButton> buttons) {
		this.buttons = buttons;
	}
	
	public void addControlledArmyButton(Army army) {
		ControlledArmyButton j=new ControlledArmyButton(army);
		j.setText("Controlled Army "+(buttons.size()+1)+"");
		buttons.add(j);
		this.add(j);
	}
	
	public void removeControlledArmyButton(Army army) {
		
		ControlledArmyButton b=null;
		for(int i=0;i<buttons.size();i++) {
			if(buttons.get(i).getArmy()==army) {
				b=buttons.get(i);
				buttons.remove(i);
				break;
			}	
		}
		this.remove(b);
		
	}

	public static void main(String[] args) {
		JFrame j =new JFrame();
		Army a=new Army("Cairo");
		Army aa=new Army("Cairo");
		Army aaa=new Army("Cairo");
		ContolledArmyPanel c=new ContolledArmyPanel();
		c.addControlledArmyButton(aa);
		c.addControlledArmyButton(aaa);
		//c.removeControlledArmyButton(a);
		j.add(c);
		j.setVisible(true);
		
	}

}
