package View;
import java.awt.*;
import javax.swing.*;
import units.*;

public class ArmyView extends JButton{
	
	private Army a;

	public Army getA() {
		return a;
	}

	public void setA(Army a) {
		this.a = a;
	}

	public ArmyView(Army a) {
		this.a=a;
	}

}
