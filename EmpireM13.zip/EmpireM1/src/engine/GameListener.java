package engine;

import buildings.Building;
import units.Army;
import units.Unit;

public interface GameListener {
	public void OnTargetCity(Army army, String targetName);
	public void OnEndTurn();
	public void OnOccupy(Army a, String cityName);
	public void OnRecruitUnit(String type,String cityName);
	public void OnUpgradeBuilding(Building b);
	public void OnInitiateArmy(Army army,Unit unit);
	public void OnLaySiege(Army army,City city);
	public void OnRemoveArmy(Army attacker);
	public void Onattack(Unit unit, Army attacker, Unit u, Army defender, int past, boolean b);
	public void OnBuilt(Building b);
	void OnHandleAttackedUnit(Unit u, Army a, int index);
	public void onRelocateUnit(Army army);
}
