package engine;

import buildings.Building;
import units.Army;
import units.Unit;

public interface PlayerListenr {
	public void OnRecruitUnit(String type,String cityName);
	public void OnUpgradeBuilding(Building b);
	public void OnInitiateArmy(Army army,Unit unit);
	public void OnLaySiege(Army army,City city);
	public void OnBuilt(Building a);
}
